<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    $sql = "SELECT * FROM info WHERE email = '$email'";
    $result = $conn->query($sql);

    if (empty($_POST['email']) || empty($_POST['password'])) {
        echo "Email and password are required.";
    } else {
        // Proceed with database query and validation
    
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Debugging: Check if the fetched password matches the entered password
      //  echo "Stored Password: " . $row['password'] . "<br>";
       // echo "Entered Password: " . $password . "<br>";
        if ($password === $row['password']) {
            $_SESSION['email'] = $email;
            header("Location: welcome.php");
            exit();
        } else {
            echo "Invalid email or password";
        }
    } else {
        echo "No user found with that email";
    }

    $conn->close();
}
}
?>

-<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Travel Carousel Design</title>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css'>
  <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
</head>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Roboto:wght@300;400;500&display=swap");

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

section{
  position: relative;
  width: 100%;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: url(images/b5.jpg);
  overflow: hidden;
	flex-direction: column;
	
}

.swiper {
  width: 100%;
  padding-top: 50px;
  padding-bottom: 50px;
}

.swiper-slide {
  width: 300px;
  height: 400px;
  box-shadow: 0 15px 50px rgba(0, 0, 0, 0.2);
  filter: blur(1px);
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  justify-content: end;
  align-items: self-start;
}

.swiper-slide-active {
  filter: blur(0px);
}

.swiper-pagination-bullet,
.swiper-pagination-bullet-active {
  background: #fff;
}

.swiper-slide span {
  text-transform: uppercase;
  color: #fff;
  background: #1b7402;
  padding: 7px 18px 7px 25px;
  display: inline-block;
  border-radius: 0 20px 20px 0px;
  letter-spacing: 2px;
  font-size: 0.8rem;
  font-family: "Open Sans", sans-serif;
}

.swiper-slide--one span {
  background: #62667fdf;
}

.swiper-slide--two span {
  background: #087ac4;
}

.swiper-slide--three span {
  background: #b45205;
}

.swiper-slide--four span {
  background: green;
}

.swiper-slide--five span {
  background:  #62667f;
}

.swiper-slide--six span {
  background:  #087ac4;
}

.swiper-slide--seven span {
  background:  #b45205;
}

.swiper-slide--eight span {
  background:green;
}
.swiper-slide--nine span {
  background:#62667f;
}
.swiper-slide--ten span {
  background:  #087ac4;
}

.swiper-slide h2 {
  color: #fff;
  font-family: "Roboto", sans-serif;
  font-weight: 400;
  font-size: 1.3rem;
  line-height: 1.4;
  margin-bottom: 15px;
  padding: 25px 45px 0 25px;
}

.swiper-slide p {
  color: #fff;
  font-family: "Roboto", sans-serif;
  font-weight: 300;
  display: flex;
  align-items: center;
  padding: 0 25px 35px 25px;
}

.swiper-slide svg {
  color: #fff;
  width: 22px;
  height: 22px;
  margin-right: 7px;
}

.swiper-slide--one {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/beirut.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--two {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/saidaa.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--three {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/haresa.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--four {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/telefriq.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--five {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/tyree.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--six {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/JEITA.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--seven {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/faraya.jpg)
      no-repeat 50% 50% / cover;
}
.swiper-slide--eight {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/cedars.jpg)
      no-repeat 50% 50% / cover;
}
.swiper-slide--nine {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/Beaufort.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-slide--ten {
  background: linear-gradient(to top, #0f2027, #203a4300, #2c536400),
    url(images/baatara.jpg)
      no-repeat 50% 50% / cover;
}

.swiper-3d .swiper-slide-shadow-left,
.swiper-3d .swiper-slide-shadow-right {
  background-image: none;
}

.first{
   margin-bottom: 30px;
    color: #e20707;
    font-size: 30px;
    text-transform: uppercase;
    margin-left: 20px;
	
}


.second a{
  border-radius: 100px 100px ;  
	background-color: white;
  border-top-left-radius: 20px;
  border-bottom-right-radius: 30px;
    color:green;
    font-size: 25px;
    margin-left: 100px;
   padding-left: 10px;


}
.second a:hover{
        color:red;

}


</style>
<body>
 
<section>
  <a href="home.php" class="first"><i class="ri-flight-takeoff-line" style="color:red; font-size: 40px;"></i> <span style="color:whitesmoke;  font-size: 40px;">LEB</span><span style="color: green;  font-size: 40px;">AN</span><span style="color: red;  font-size: 40px;">ON</span>
  </a>
  <a href="map.php" ><i class="ri-map-pin-line" style="color: red;"></i><span style="color: red; font-size: 20px; text-align: center;">Interactive Map of Lebanon :</span>  </a>
  <div class="swiper">
    <div class="swiper-wrapper">  
      <div class="swiper-slide swiper-slide--one">
        <span>Capital of lebanon</span>
        <div>
          <h2>Enjoy vibrant nightlife </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a href="beirut.php" style="color:rgba(128, 128, 128, 0.701);"> Beirut</a>
          </p>
        </div>
      </div>
      <div class="swiper-slide swiper-slide--two">
        <span>Coastal city</span>
        <div>
          <h2>Enjoy historic charm
            </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            <a style="color:#087ac4;;">Saida</a> 
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--three">
        <span> Iconic Our Lady of Lebanon Statue</span>
        <div>
          <h2>Enjoythe overlooking to the Mediterranean, 
           </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            <a  style="color: #b45205;;">Harissa</a>
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--four">
        <span>Breathtaking Panoramic</span>
        <div>
          <h2>Enjoy the  stunning Lebanese landscape  
        </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a  style="color:green;"> Telefrique Lebanon </a>
          </p>
        </div>
      </div>
       
      
      <div class="swiper-slide swiper-slide--five">
        <span>Rich History</span>
        <div>
          <h2>Enjoy the beauty of ancient ruins 
          </h2>
          <p>

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a style="color: #62667fdf;">Tyre</a> 
          </p>
        </div>
      </div>
      <div class="swiper-slide swiper-slide--six">
        <span> Ethereal Beauty</span>
        <div>
          <h2>Enjoy the mesmerizing underground wonderland. </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a style="color: #087ac4;"> Jeita Grotto</a>
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--seven">
        <span>Picturesque Charm</span>
        <div>
          <h2>Enjoy the  majestic mountains</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a href="locations.html" style="color:  #b45205;;"> Faraya Village </a>
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--eight">
        <span>Ancient Sentinels</span>
        <div>
          <h2>Enjoy the towering boughs whispering</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a  style="color: green;"> Cedars</a>
          </p>
        </div>
      </div>
       
      <div class="swiper-slide swiper-slide--nine">
        <span>Majestic Medieval Architecture</span>
        <div>
          <h2>Enjoy the exudes timeless beauty </h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a style="color: #62667fdf;"> Beaufort Castle </a>
          </p>
        </div>
      </div>
       
      <div class="swiper-slide swiper-slide--ten">
        <span>Breathtaking Natural Wonder</span>
        <div>
          <h2>Enjoy the view .</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
           <a  style="color: #087ac4;">Baatara</a>
          </p>
        </div>
      </div>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</section>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js'></script>
  <script>
    var swiper = new Swiper(".swiper", {
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: "auto",
  coverflowEffect: {
    rotate: 0,
    stretch: 0,
    depth: 100,
    modifier: 2,
    slideShadows: true
  },
  keyboard: {
    enabled: true
  },
  mousewheel: {
    thresholdDelta: 70
  },
  spaceBetween: 60,
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true
  }
});
  </script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lebanon Tour Planner</title>
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-image: url(images/lb1.jpg);
    margin: 0;
    padding: 0;
}

.container {
    max-width: 600px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

h1 {
    text-align: center;
    color:red;
}

form {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

label {
    font-size: 18px;
    color: #555;
}

select {
    padding: 10px;
    font-size: 16px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.c {
    padding: 10px 20px;
    font-size: 16px;
    color: #fff;
    background-color: red;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.c:hover {
    background-color: green;
}

#output {
    margin-top: 20px;
    font-size: 18px;
    color: #333;
}
.b{
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #4CAF50; 
            color: white;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Add transition for hover effect */
        }
        .b:hover {
            background-color: #45a049; 
        }
</style>
<body>
    <div class="container">
        <h1>Lebanon Tour Planner</h1>
        <form id="tour-form">
            <label for="cities" style="color: red;">Select Cities:</label>
            <select id="cities" multiple>
                <option value="beirut">Beirut</option>
                <option value="harissa">Harissa</option>
                <option value="saida">Saida</option>
                <option value="tyre">Tyre</option>
                <option value="jeita">Jeita Grotto</option>
                <option value="faraya">Faraya Village</option>
                <option value="cedars">Cedars</option>
                <option value="beaufort">Beaufort Castle</option>
                <option value="baatara">Baatara</option>
            </select>
            <button type="button" class="c" onclick="calculateDistance()">Calculate Distance</button>
        
        </form>
        <div id="output"></div>
        <button type="button" class="b"  id="back">Go Back</button>
    </div>
    <script>
        const cities = {
    beirut: { lat: 33.8938, lon: 35.5018 },
    harissa: { lat: 33.9802, lon: 35.6368 },
    saida: { lat: 33.5631, lon: 35.3689 },
    tyre: { lat: 33.2707, lon: 35.2038 },
    jeita: { lat: 33.9433, lon: 35.6861 },
    faraya: { lat: 33.9933, lon: 35.8589 },
    cedars: { lat: 34.2476, lon: 36.0450 },
    beaufort: { lat: 33.3311, lon: 35.5314 },
    baatara: { lat: 34.1268, lon: 35.8689 }
};

function calculateDistance() {
    const selectedOptions = document.getElementById('cities').selectedOptions;
    const selectedCities = Array.from(selectedOptions).map(option => option.value);

    if (selectedCities.length < 2) {
        alert('Please select at least two cities.');
        return;
    }

    let totalDistance = 0;
    for (let i = 0; i < selectedCities.length - 1; i++) {
        const city1 = cities[selectedCities[i]];
        const city2 = cities[selectedCities[i + 1]];
        totalDistance += haversineDistance(city1, city2);
    }

    document.getElementById('output').innerText = `Total Distance: ${totalDistance.toFixed(2)} km`;
}

function haversineDistance(coord1, coord2) {
    const R = 6371; // Radius of the Earth in km
    const dLat = toRadians(coord2.lat - coord1.lat);
    const dLon = toRadians(coord2.lon - coord1.lon);
    const lat1 = toRadians(coord1.lat);
    const lat2 = toRadians(coord2.lat);

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

function toRadians(degrees) {
    return degrees * (Math.PI / 180);
}
document.getElementById('back').addEventListener('click', function() {
            window.location.href = 'map.php'; 
          });
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="login1.css">

</head>

<body>

    <a href="https://en.wikipedia.org/wiki/Lebanon" class="first"><i class="ri-flight-takeoff-line" style="color:red; font-size: 40px;"></i> <span style="color:whitesmoke;  font-size: 40px;">LEB</span><span style="color: green;  font-size: 40px;">AN</span><span style="color: red;  font-size: 40px;">ON</span>
    </a>
    <nav class="second">
   
    </nav>
    

    <div class="container" id="container">
        <div class="form-container sign-up-container">
        
        <form action="signup_action.php" method="POST">
            <h1 style="color: red;" >Create Account</h1>
            <div class="social-container">
                <a href="#"><i class="ri-facebook-fill"></i></a>
                <a href="#"><i class="ri-google-fill"></i></a>
                <a href="#"><i class="ri-linkedin-fill"></i></a>
            </div>
            <span>Or use your email for registration</span>
            <input type="text" name="username" placeholder="Name">
            <input type="email" name="email" placeholder="Email">
            <input type="password" name="password" placeholder="Password" >
           
            <button onclick="Signup()">Sign up</button>
        </form>
        </div>
        <div class="form-container sign-in-container">
            <form action="login_action.php" method="POST">
                <h1 style="color:red;">Login</h1>
                <div class="social-container">
                <a href="#"><i class="ri-facebook-fill"></i></a>
                <a href="#" ><i class="ri-google-fill"></i></a>
                <a href="#"><i class="ri-linkedin-fill"></i></a>
            </div>
            <span>Or use your account</span>
            <input  type="email" name="email"  placeholder="Email">
            <input  type="password" name="password" placeholder="Password">
        
            <a href="#" style="color: red;">Forgot Your Password</a>
            <button onclick="login()">Login</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <b> <h1>Welcome Back!</h1>
                    <p>To keep connected with our agency login with your personal info</p></b>
                    <button class="ghost" id="signIn">Login</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hello, There!</h1>
                    <p>Enter your details and start your healing journey with us</p>
                    <button class="ghost" id="signUp">Sign up</button>
                </div>
            </div>
        </div>
        </div>
        
        <script type="text/javascript">
         
            const signUpButton = document.getElementById('signUp');
            const signInButton = document.getElementById('signIn');
            const container = document.getElementById('container');
        
            signUpButton.addEventListener('click', () => {
                container.classList.add("right-panel-active");
            });
            signInButton.addEventListener('click', () => {
                container.classList.remove("right-panel-active");
            });

        </script>
       <script src="login.js" ></script>
</body>
</html>
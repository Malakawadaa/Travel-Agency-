function login(){
    let email= document.getElementsByTagName("input")[3].value;
    let password = document.getElementsByTagName("input")[4].value;
    if(email=="" || password==""){
        alert("There are missing required field");

    }}

    function Signup(){
        let name = document.getElementsByTagName("input")[0].value;
        let email = document.getElementsByTagName("input")[1].value;
        let password = document.getElementsByTagName("input")[2].value;
        if( name=="" || email=="" || password==""){
            alert("There are missing required field");

        } 
        else {
                if(!/\S+@\S+\.\S+/.test(email)){
                   alert('please enter a valid email');
                }
                else if
                    ( password.length<8){
                      //  document.getElementById("errormsg").innerHTML="'please enter a valid password'";
                       alert('please enter a valid password');
                    
                }
            } 
             };
        
       
   
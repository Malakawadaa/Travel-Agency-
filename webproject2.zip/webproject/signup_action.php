<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
   
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

.container {
    width: 50%;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
 


</style>
<body>
    <div class="container">
    <?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']); // No hashing

    // Check if email and password fields are not empty
    if (empty($email) || empty($password)) {
        echo "Email and password are required.";
    } else {
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format.";
        } 
        // Validate password length
        elseif (strlen($password) < 8) {
            echo "Password must be at least 8 characters long.";
        } else {
            // Check if the email already exists in the database
            $check_sql = "SELECT * FROM info WHERE email = '$email'";
            $check_result = $conn->query($check_sql);
            if ($check_result->num_rows > 0) {
                // Email already exists, display error message
                echo "Error: This email is already registered.";
            } else {
                // Email is unique, proceed with insertion
                $insert_sql = "INSERT INTO info (username, email, password) VALUES ('$username', '$email', '$password')";

                if ($conn->query($insert_sql) === TRUE) {
                    $_SESSION['username'] = $username;
                    header("Location: newenter.php");
                    exit();
                    } else {
                    echo "Error: " . $insert_sql . "<br>" . $conn->error;
                }
            }
        }
    }

    $conn->close();
}
?>


       
    </div>
</body>
</html>

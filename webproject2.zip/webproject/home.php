<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Agency</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="home.css">
</head>


<body>
    <header>
        <div class="logo">
            <a href="https://en.wikipedia.org/wiki/Lebanon">
                <i class="ri-flight-takeoff-line" style="color: red;"></i>
                <span style="color:whitesmoke">LEB</span><span style="color:green;">AN</span><span style="color:red;">ON</span>
            </a>
        </div>
        <button class="hamburger" id="hamburger">&#9776;</button>
        <nav class="navbar" id="navbar">
            <a href="home.php">Home</a>
            <a href="weather.php">Weather</a>
            <a href="event.php">Events</a>
            <a href="packages1.php">Packages</a>
            <a href="lebanon.php">Lebanon</a>
            <a href="logout.php">Logout</a>
        </nav>
        <div class="icons">
            <i class="fas fa-search" id="search-btn"></i>
            <i class="fas fa-user" id="user-btn"></i>
        </div>
        <form action="" class="search-bar-container">
            <input type="search" id="search-bar" placeholder="Search here...">
            <label for="search-bar" class="fas fa-search"></label>
        </form>
        <script>
        const hamburger = document.getElementById('hamburger');
        const navbar = document.getElementById('navbar');

        hamburger.addEventListener('click', () => {
            navbar.classList.toggle('active');
        });
    </script>
    </header>
    <main>
        <section class="intro">
            <p style="text-align: center;"><strong style="color: red;font-size: 20px; ">Switzerland of the East</strong> <a href="text.php" style="color: green;">Read more...</a></p>
        </section>
        <section class="media">
            <img src="images/flag1.jpg" alt="Flag 1" class="flag">
            <video src="images/v.mp4" autoplay loop  class="video"></video>
            <img src="images/flag2.jpg" alt="Flag 2" class="flag">
        </section>
    </main>
  
    <footer class="foot">
            <div class="box-container">
            <div class="box">
                <h3>Extra Links</h3>
                <a href="#"><i class="fas fa-angle-right"></i> Ask Questions</a>
                <a href="#"><i class="fas fa-angle-right"></i> About Us </a>
                <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i> Terms of Use</a>
            </div>
            <div class="box">
                <h3>Contact Info</h3>
                <a href="#"><i class="fas fa-phone"></i> +961-71 456 789</a>
                <a href="#"><i class="fas fa-phone"></i> +961-71 222 333</a>
                <a href="#"><i class="fas fa-envelope"></i> travelagency@gmail.com</a>
                <a href="#"><i class="fas fa-map"></i> Lebanon, AL-Janoub</a>
            </div>
            <div class="box">
                <h3>Follow Us</h3>
                <a href="#"><i class="fab fa-facebook-f"></i> Facebook</a>
                <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
                <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                <a href="#"><i class="fab fa-linkedin"></i> LinkedIn</a>
            </div>
        </div>
        <div class="credit">Created by <span>Malak Awada | Lana Arbid | Doaa Nassar</span></div>
    </footer>
    <script>
        const searchBtn = document.getElementById("search-btn");
        const searchBar = document.querySelector(".search-bar-container");

        searchBtn.addEventListener("click", () => {
            searchBtn.classList.toggle("fa-times");
            searchBar.classList.toggle("active");
        });
    </script>
  
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lebanon Events</title>
    <style>
 body {
    font-family: 'Open Sans', Arial, sans-serif;
    padding: 20px;
    background-color: #fff;
    margin: 0;
    color: #333;
}

h1 {
    text-align: center;
    color: #333;
    margin-bottom: 30px;
}

#events {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.event-card {
    background-image: url('images/kokk.webp');
    background-size: cover;
    background-position: center;
    border: 1px solid #ddd;
    padding: 20px;
    width: calc(33% - 40px);
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    color: green;
    transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
    background-blend-mode: overlay;
    background-color: rgba(255, 255, 255, 0.3); 
}


.event-card h3 {
    border: 1px solid black;
    background:black;
    margin: 0 0 10px;
    color: red;
    font-weight: 600;
}

.event-card p {
    margin: 5px 0;
    color:black; 
}

.event-card:hover {
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    transform: translateY(-5px); 
}

.loading {
    text-align: center;
    font-size: 18px;
    color: #555;
}

.error {
    text-align: center;
    color: red;
    font-weight: bold;
}

/* Styling the button */
.c {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    color: #fff;
    background-color:blue;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
    text-align: center;
    text-decoration: none;
}

.c:hover {
    background-color: red; 
    transform: translateY(-2px); 
  
}
.c a {
    color: inherit; 
    text-decoration: none; /* Remove underline */
}

    </style>
</head>
<body>
 
    <div>
        <button class="c" id="backHome" ><a href="home.php">back Home</a></button>
    </div> 
    
    <h1>Upcoming Events in Lebanon</h1>
    <div id="events" class="loading">Loading events...</div>

    <script>
        // Fetch and display events
        function fetchEvents() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'events.php', true); // Ensure this matches the backend file
            xhr.onload = function () {
                if (this.status === 200) {
                    const events = JSON.parse(this.responseText);
                    if (events.length > 0) {
                        let output = '';
                        events.forEach(event => {
                            output += `
                                <div class="event-card">
                                    <h3>${event.title}</h3>
                                    <p><strong>Date:</strong> ${event.date}</p>
                                    <p><strong>Location:</strong> ${event.location}</p>
                                    <p>${event.description}</p>
                                </div>
                            `;
                        });
                        document.getElementById('events').innerHTML = output;
                    } else {
                        document.getElementById('events').innerHTML = '<p class="error">No events available.</p>';
                    }
                } else {
                    document.getElementById('events').innerHTML = '<p class="error">Failed to load events.</p>';
                }
            };
            xhr.onerror = function () {
                document.getElementById('events').innerHTML = '<p class="error">Error occurred while fetching events.</p>';
            };
            xhr.send();
        }

        // Fetch events on page load
        fetchEvents();
    </script>
</body>
</html>

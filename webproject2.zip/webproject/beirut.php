<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beirut</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
     
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }

        .a {
            background-color: red;
            text-align: center;
            padding: 10px;
        }

        h1 {
            color: red;
            text-align: center;
        }

        .b {
            font-size: 20px;
            padding: 10px;
        }

        .text1, .text3, .text2 {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            padding: 10px;
        }

        .text1 p {
            flex: 1 1 300px;
            padding: 10px;
        }

        .text3 img, .text1 img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .m {
            text-align: center;
        }

        .c {
            position: fixed;
            bottom: 10px;
            right: 10px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            background-color: red;
            color: white;
            border: 1px solid white;
            border-radius: 5px;
            z-index: 1000;
        }

        .c:hover {
            background-color: green;
        }

        ul {
            padding: 10px;
            list-style-type: disc;
            margin-left: 20px;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 24px;
            }

            .b {
                font-size: 16px;
            }

            .text1, .text3 {
                gap: 5px;
            }

            .c {
                font-size: 14px;
                padding: 8px 15px;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 20px;
            }

            .b {
                font-size: 14px;
            }

            .c {
                font-size: 12px;
                padding: 5px 10px;
            }

            ul {
                padding-left: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="a">
        <a href="home.php" class="first">
            <i class="ri-flight-takeoff-line" style="color:white; font-size: 40px;"></i> 
            <span style="color:green; font-size: 40px;">LEBANON</span>
        </a>
    </div>
    <div>
        <button class="c" id="TouristCalculator">Go buy</button>
    </div>
    <h1>Discover Beirut: The Jewel of the Mediterranean</h1>
    <div class="text1">
        <p>Welcome to Beirut, the Paris of the Middle East! This vibrant city is a blend of ancient history and modern elegance, offering a unique experience for every traveler. A city where tradition meets modernity, where every street tells a story, and every visitor is a friend. Book your trip today and discover why Beirut is the beating heart of Lebanon. Here’s why Beirut should be your next destination:</p>
        <img src="images/beirut1.jpg" alt="Beirut View">
    </div>
    
    <h1>Culinary Delights:</h1>
    <p class="b">Beirut is a gastronomic paradise, renowned for its exquisite Lebanese cuisine. Indulge in mouth-watering dishes such as:</p>
    <h1>Here are some of the most important dishes in Beirut:</h1>
    <div class="text3">
        <img src="images/mtabal.jpg" alt="Mtabal">
        <img src="images/homos.jpg" alt="Homos">
        <img src="images/tabulewfatosh.jpg" alt="Tabule & Fattoush">
        <img src="images/shwerma.jpg" alt="Shawarma">
        <img src="images/kebeh.jpg" alt="Kebbeh">
        <img src="images/ghnefe.jpg" alt="Ghnefe">
        <img src="images/baklava.jpg" alt="Baklava">
    </div>
    
    <h1>Famous Personalities:</h1>
    <p class="b">Beirut has produced a wealth of talent in various fields. Notable figures include:</p>
    <ul class="b">
        <li><a href="https://en.wikipedia.org/wiki/Fairuz">Fairuz:</a> The legendary singer, known as the “Soul of Lebanon,” whose music has touched millions.</li>
        <li><a href="https://en.wikipedia.org/wiki/Amin_Maalouf">Amin Maalouf:</a> Acclaimed author and member of the French Academy.</li>
        <li><a href="https://en.wikipedia.org/wiki/Elie_Saab">Elie Saab:</a> Internationally renowned fashion designer.</li>
    </ul>
    <div class="text3">
        <img src="images/fayroz.jpg" alt="Fairuz">
        <img src="images/amin maalouf.jpg" alt="Amin Maalouf">
        <img src="images/elie saab.jpg" alt="Elie Saab">
    </div>

    <h1>Music and Nightlife:</h1>
    <p class="b">Beirut’s music scene is as diverse as its culture. Enjoy live performances ranging from traditional Arabic music to contemporary genres. The city’s nightlife is legendary, with bustling clubs, bars, and rooftop lounges in areas like Gemmayzeh and Mar Mikhael. Dance the night away to the beats of world-class DJs and enjoy the vibrant, energetic atmosphere.</p>
    <div class="text3">
        <img src="images/night1.jpg" alt="Nightlife 1">
        <img src="images/night5.jpg" alt="Nightlife 2">
        <img src="images/night2.jpg" alt="Nightlife 3">
        <img src="images/night4.jpg" alt="Nightlife 4">
        <img src="images/night3.jpg" alt="Nightlife 5">
    </div>
    
    <script>
        document.getElementById('TouristCalculator').addEventListener('click', function() {
            window.location.href = 'calculate.php';
        });
    </script>
</body>
</html>

<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Array of events
$events = [
    [
        "id" => 1,
        "title" => "Beirut Art Festival",
        "date" => "2024-12-25",
        "location" => "Beirut Downtown",
        "description" => "A celebration of contemporary art and culture in the heart of Beirut.",
        "reviews" => ["Amazing event!", "Loved the exhibits!"],
        "rsvp" => 150
    ],
    [
        "id" => 2,
        "title" => "Tripoli Food Fair",
        "date" => "2024-12-30",
        "location" => "Rashid Karami Exhibition Center",
        "description" => "Savor the best of Tripoli's culinary delights.",
        "reviews" => ["Delicious food!", "Great atmosphere."],
        "rsvp" => 200
    ],
    [
        "id" => 3,
        "title" => "Byblos Music Night",
        "date" => "2025-01-10",
        "location" => "Byblos Old Port",
        "description" => "Experience an unforgettable evening of live music by the sea.",
        "reviews" => ["Spectacular performance!", "The venue is magical."],
        "rsvp" => 300
    ],
    [
        "id" => 4,
        "title" => "Chouf Nature Hike",
        "date" => "2025-01-15",
        "location" => "Chouf Cedars Reserve",
        "description" => "A guided hike through the breathtaking Chouf Cedars Reserve.",
        "reviews" => ["Perfect for nature lovers.", "Highly recommended!"],
        "rsvp" => 120
    ],
    [
        "id" => 5,
        "title" => "Zahle Wine Tasting",
        "date" => "2025-02-05",
        "location" => "Zahle Vineyards",
        "description" => "Sample the finest wines from Lebanon's Bekaa Valley.",
        "reviews" => ["Exceptional wines!", "A must-visit for wine enthusiasts."],
        "rsvp" => 180
    ],
    [
        "id" => 6,
        "title" => "Sidon Historical Tour",
        "date" => "2025-02-20",
        "location" => "Sidon Sea Castle",
        "description" => "Explore the rich history of Sidon with a guided tour.",
        "reviews" => ["Very informative.", "Loved the ancient architecture."],
        "rsvp" => 100
    ],
    [
        "id" => 7,
        "title" => "Baalbek Night Festival",
        "date" => "2025-03-15",
        "location" => "Baalbek Ruins",
        "description" => "A night of cultural performances at the historic Baalbek Ruins.",
        "reviews" => ["Magical setting!", "Incredible experience."],
        "rsvp" => 250
    ],
    [
        "id" => 8,
        "title" => "Akkar Farmers' Market",
        "date" => "2025-03-30",
        "location" => "Akkar Town Square",
        "description" => "Discover fresh produce and local crafts at this charming market.",
        "reviews" => ["Great local products.", "Friendly atmosphere."],
        "rsvp" => 90
    ],
    [
        "id" => 9,
        "title" => "Hermel Poetry Night",
        "date" => "2025-04-10",
        "location" => "Hermel Cultural Center",
        "description" => "An evening celebrating the beauty of Lebanese poetry.",
        "reviews" => ["Beautiful recitations.", "Very inspiring."],
        "rsvp" => 75
    ],
    [
        "id" => 10,
        "title" => "Batroun Water Sports Festival",
        "date" => "2025-04-25",
        "location" => "Batroun Beach",
        "description" => "Enjoy thrilling water sports and beach activities in Batroun.",
        "reviews" => ["So much fun!", "Perfect for families."],
        "rsvp" => 220
    ]
];

// Output events as JSON
echo json_encode($events);
?>


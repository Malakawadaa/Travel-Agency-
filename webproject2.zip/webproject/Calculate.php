<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beirut Tourist Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
            background-image: url(images/flagl.jpg ) ; 
            background-size: cover;
            background-position: center;
        }
        .container {

            max-width: 800px;
          
            margin: 150px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* aamltu transparency la el container */
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3); /* zdet subtle shadow */
        }
        h1 {
            text-align: center;
            color: #333; /* Darken the text color */
        }
        .options {
            margin-bottom: 20px;
        }
        .option-item {
            margin-bottom: 10px;
        }
        label {
            color: #555; /* Darken label text color */
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #4CAF50; 
            color: white;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Add transition for hover effect */
        }
        button:hover {
            background-color: #45a049; 
        }
        .total-price {
            font-size: 20px;
            font-weight: bold;
            color: #333; 

        }
        .bt{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Beirut Tourist Calculator</h1>
        <div class="options">
            <div class="option-item">
                <label for="attractions">Attractions</label>
                <select id="attractions">
                    <option value="0">Select...</option>
                    <option value="10">National Museum of Beirut ($10)</option>
                    <option value="5">Pigeon Rocks ($5)</option>
                    <option value="3">Martyrs’ Square ($3)</option>
                    <option value="8">Sursock Museum ($8)</option>
             
                </select>
            </div>
            <div class="option-item">
                <label for="zeytouna">Zeytouna Bay (Food)</label>
                <select id="zeytouna">
                    <option value="0">Select...</option>
                    <option value="15">Pasta ($15)</option>
                    <option value="10">Pizza ($10)</option>
                    <option value="8">Burger ($8)</option>
                    <option value="8">Shawarma ($8)</option>
                    <option value="12">Salad ($12)</option>
                    <option value="18">Seafood Platter ($18)</option>
                  
                </select>
            </div>
            <div class="option-item">
                <label for="drink">Drinks</label>
                <select id="drink">
                    <option value="0">Select...</option>
                    <option value="2">Nescafe ($2)</option>
                    <option value="3">Lemon Juice ($3)</option>
                    <option value="2">Pepsi ($2)</option>
                    <option value="2">Ice Tea ($2)</option>
                    <option value="2">Cola ($2)</option>
                    <option value="3">Orange Juice ($3)</option>
                    <option value="3">Dark Blue ($3)</option>
              
                </select>
            </div>
        </div>
        <button onclick="calculateTotal()">Calculate Total</button>
        <button onclick="resetForm()">Reset</button>
       
        <p class="total-price">Total Price: <span id="totalPrice">$0</span></p>
    </div>
    <div class="bt">
        <button id="back">Go Back</button>
    </div>
    <script>
        function calculateTotal() {
            let total = 0;
            const attractions = document.getElementById('attractions');
            const zeytouna = document.getElementById('zeytouna');
            const drink = document.getElementById('drink');

            if (attractions.value !== '0') total += parseFloat(attractions.value);
            if (zeytouna.value !== '0') total += parseFloat(zeytouna.value);
            if (drink.value !== '0') total += parseFloat(drink.value);

            document.getElementById('totalPrice').textContent = `$${total}`;
        }

        function resetForm() {
            document.querySelectorAll('select').forEach(select => select.selectedIndex = 0);
            document.getElementById('totalPrice').textContent = '$0';
        }
        
          document.getElementById('back').addEventListener('click', function() {
            window.location.href = 'beirut.php'; 
          });
    </script>
  
</body>
</html>

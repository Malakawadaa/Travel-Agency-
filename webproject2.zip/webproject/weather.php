<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather in Lebanon</title>
    <style>
        body {
            background-image: url('images/kokk.webp');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            height: 100vh; /* Adjust height for responsiveness */
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .weather-container {
            background: rgba(255, 255, 255, 0.5); /* Semi-transparent background */
            padding: 20px;
            border-radius: 15px;
            max-width: 400px;
            width: 90%; /* Adjust width for smaller screens */
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .weather-container h2 {
            margin: 0 0 20px;
            font-size: 24px;
        }

        .weather-container p {
            font-size: 18px;
            margin: 10px 0;
        }

        button, .city-select {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .refresh-button {
            background-color: red;
            color: white;
        }

        .refresh-button:hover {
            background-color: green;
        }

        .city-select {
            background-color: green;
            color: white;
            width: 100%; /* Make dropdown stretch on small screens */
        }

        .city-select:hover {
            background-color: red;
        }

        .back {
            background-color: #4CAF50;
            color: white;
            padding: 10px 170px;
            margin: 4px auto;
        }

        .back:hover {
            background-color: red;
        }

        @media (max-width: 768px) {
            .weather-container {
                max-width: 90%;
            }

            button, .city-select {
                padding: 10px;
                font-size: 14px;
            }

            .back {
                padding: 10px 50px;
            }
        }

        @media (max-width: 480px) {
            .weather-container {
                padding: 15px;
            }

            h2 {
                font-size: 20px;
            }

            p {
                font-size: 16px;
            }

            button, .city-select {
                font-size: 14px;
                width: 100%;
            }

            .back {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
    </style>
    <script>
        function fetchWeather() {
            const city = document.getElementById('city').value;
            window.location.href = `?city=${city}`; // Reload page with selected city as a query parameter
        }
    </script>
</head>
<body>
<div class="weather-container">
    <?php
    $defaultCity = "Beirut"; // Default city if no city is selected
    $city = isset($_GET['city']) ? $_GET['city'] : $defaultCity;
    $apiKey = "2cf5fc26ac0976e20e5c808469c17e50"; 
    $apiUrl = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric";

    $response = file_get_contents($apiUrl);

    if ($response) {
        $data = json_decode($response, true);

        if ($data['cod'] == 200) { // Check if the response is successful
            echo "<h2>Weather in $city</h2>";
            echo "<p>Temperature: " . $data['main']['temp'] . "°C</p>";
            echo "<p>Condition: " . ucfirst($data['weather'][0]['description']) . "</p>";
            echo "<p>Humidity: " . $data['main']['humidity'] . "%</p>";
            echo "<p>Wind Speed: " . $data['wind']['speed'] . " m/s</p>";
        } else {
            echo "<p>Error: " . $data['message'] . "</p>";
        }
    } else {
        echo "<p>Unable to fetch weather data.</p>";
    }
    ?>
    <button class="refresh-button" onclick="location.reload()">Refresh Weather</button>
    <form>
    <br>
        <label for="city">Select a City:</label>
     
        <select id="city" name="city" class="city-select" onchange="fetchWeather()">
            <option value="Beirut" selected>Beirut</option>
            <option value="Tripoli">Tripoli</option>
            <option value="Tyre">Tyre</option>
            <option value="Akkar">Akkar</option>
            <option value="Zahle">Zahle</option>
            <option value="Sidon">Sidon</option>
            <option value="Baabda">Baabda</option>
            <option value="Batroun">Batroun</option>
            <option value="Byblos">Byblos</option>
            <option value="Bcharre">Bcharre</option>
            <option value="Chouf">Chouf</option>
            <option value="Hermel">Hermel</option>
            <option value="Jbeil">Jbeil</option>
        </select>
    </form>
    <br>
    <button type="button" class="back" id="b">Back</button>
    <script>
        document.getElementById('b').addEventListener('click', function () {
            window.location.href = 'home.php';
        });
    </script>
</div>
</body>
</html>

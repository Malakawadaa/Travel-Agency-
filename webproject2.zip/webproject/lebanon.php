<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        header .first {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        nav {
            display: flex;
            justify-content: center;
            margin-bottom: 10px;
        }
        nav a {
            color: white;
            margin: 0 10px;
            text-decoration: none;
            padding: 5px 10px;
        }
        nav a:hover{
            color: green;
        }
        .text {
            padding: 20px;
        }
        .text div {
            margin-bottom: 20px;
        }
        .text img {

            width: 300px;
            height: auto;
        }
        .ok {
         
            padding: 20px;
            text-align: center;
        }
        .ok h1 {
            color: white;
            background-color: red;
            padding: 10px;
            display: inline-block;
            margin-bottom: 20px;
        }
        .first, .second, .third {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .ONE {
            border: red solid ;
            background-color: #f4f4f4;
            padding: 10px;
            width: calc(33.333% - 40px);
            box-sizing: border-box;
        }
        .ONE img {
            width: 100%;
           
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .first, .second, .third {
                flex-direction: column;
                align-items: center;
            }
            .ONE {
                width: 80%;
                margin-bottom: 20px;
            }
            header .first {
                flex-direction: column;
                align-items: center;
            }
            header .first i {
                margin-bottom: 10px;
            }
        }

        @media (max-width: 480px) {
            nav {
                flex-direction: column;
                align-items: center;
            }
            nav a {
                margin: 5px 0;
            }
            .ok h1 {
                margin-left: 0;
            }
            /* Adjust font sizes for smaller screens */
            .text p {
                font-size: 14px;
            }
            .ok h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <header>
        <a href="https://en.wikipedia.org/wiki/Lebanon" class="first"><i class="ri-flight-takeoff-line" style="color:white; font-size: 40px;"></i> <span style="color:red; font-size: 40px;">LEBANON</span></a>
        <nav>
            <a id="x" href="home.php">Home</a>
            <a id="x" href="weather.php">Weather</a>
            <a href="event.php">Events</a>
            <a id="x" href="packages1.php">Packages</a>
            <a id="x" href="logout.php">Logout</a>
        </nav>
    </header>
    <div class="text">
        <div class="text1">
            <p><span style="color: red; font-size: 30px;">Lebanon :</span> <br> Officially known as the Lebanese Republic, is a small country located in the Middle East on the eastern shore of the Mediterranean Sea. Despite its relatively small size, Lebanon boasts a rich history, diverse culture, and significant geopolitical importance. In addition, Lebanon is a country of contrasts and complexities, with a rich history, diverse society, and ongoing challenges. Its unique position in the Middle East makes it a key player in regional dynamics and a fascinating subject of study.</p>
            <img src="images/b6.jpg" alt="Lebanon">
        </div>
        <div class="text2">
            <p><span style="color: red; font-size: 30px;">Geography and Demographics :</span> <br> Lebanon covers an area of approximately 10,452 square kilometers (4,036 square miles), making it one of the smallest countries in the region. It shares borders with Syria to the north and east, Israel to the south, and the Mediterranean Sea to the west. The capital and largest city is Beirut, a vibrant and cosmopolitan urban center known for its historical landmarks, cultural institutions, and nightlife. Lebanon has a population of around 6 million people, including a significant number of Palestinian and Syrian refugees. The country's demographic composition is highly diverse, comprising various ethnic and religious groups. The major religions include Christianity (Maronite Catholics, Greek Orthodox, and other Christian denominations), Islam (Sunni and Shia), and Druze. This diversity is a defining feature of Lebanon's social fabric and has also been a source of both cultural richness and political complexity.</p>
            <img src="images/g1.jpg" alt="Geography and Demographics">
        </div>
        <div class="text3">
            <p><span style="color: red; font-size: 30px;">Historical Background:</span> <br> Lebanon's history dates back thousands of years and includes periods of rule by various ancient civilizations such as the Phoenicians, Assyrians, Babylonians, Persians, Greeks, Romans, Arabs, Crusaders, Ottoman Turks, and the French. The Phoenicians, who were among the earliest settlers, are particularly notable for their contributions to maritime trade and the spread of the alphabet. In modern history, Lebanon was part of the Ottoman Empire until the end of World War I, after which it came under French mandate. Lebanon gained independence from France in 1943, and its post-independence era has been marked by significant political and social developments, including the Lebanese Civil War (1975-1990), which had profound effects on the country's population and infrastructure.</p>
            <img src="images/old.jpg" alt="Historical Background">
        </div>
        <div class="text4">
            <p><span style="color: red; font-size: 30px;">Economy :</span> <br> Lebanon's economy is diverse but faces significant challenges. Key sectors include banking and finance, tourism, real estate, and agriculture. Historically, Beirut has been a financial hub in the region. However, the country has been grappling with economic instability, exacerbated by political corruption, debt, and the impacts of regional conflicts.</p>
            <img src="images/eco.jpg" alt="Economy">
        </div>
    </div>
    <div class="ok">
        <h1><strong>Explore Lebanon's Beauty</strong></h1>
        <div class="first">
            <div class="ONE">
                <h2><a href="http://www.nancyajram.com/#!/">Nancy Ajram</a></h2>
                <img src="images/NANCY.jpg" alt="Nancy Ajram">
                
            </div>
            <div class="ONE">
                <h2><a href="https://en.wikipedia.org/wiki/Fairuzs">Fairuz</a></h2>
                <img src="images/fairuz.jpg" alt="Fairuz">
            </div>
            <div class="ONE">
                <h2><a href="https://en.wikipedia.org/wiki/Najwa_Karam">Najwa Karam</a></h2>
                <img src="images/najwa.jpg" alt="Najwa Karam">
            </div>
        </div>
        <div class="second">
            <div class="ONE">
                <h2><a href="https://en.wikipedia.org/wiki/Nadine_Nassib_Njeim">Nadine Nassib Njeim</a></h2>
                <img src="images/nadin njem.jpg" alt="Nadine Nassib Njeim">
            </div>
            <div class="ONE">
                <h2><a href="https://en.wikipedia.org/wiki/Cyrine_Abdelnour">Cyrine Abdelnour</a></h2>
                <img src="images/cyrine abdelnour.jpg" alt="Cyrine Abdelnour">
            </div>
            <div class="ONE">
                <h2><a href="https://en.wikipedia.org/wiki/Ragheb_Alama">Ragheb Alama</a></h2>
                <img src="images/ragheb alama.jpg" alt="Ragheb Alama">
            </div>
        </div>
        <div class="third">
            <div class="ONE">
                <h2><a href="https://www.eliesaab.com/">Elie Saab</a></h2>
                <img src="images/elie saab.jpg" alt="Elie Saab">
            </div>
            <div class="ONE">
                <h2><a href="https://www.instagram.com/cynthiasam/">Cynthia Samuel</a></h2>
                <img src="images/cynthia.jpg" alt="Cynthia Samuel" >
            </div>
            <div class="ONE">
                <h2><a href="https://www.youtube.com/@ali-al-attar-01?sub_confirmation=1">Ali Attar</a></h2>
                <img src="images/ali attar.jpg" alt="Ali Attar" >
            </div>
        </div>
    </div>
    <footer>
        <p>MLD For Travelling in "Switzerland of the East"© All rights reserved.</p>
    </footer>
</body>
</html>

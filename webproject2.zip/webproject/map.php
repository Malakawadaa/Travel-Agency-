<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lebanon Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        #map {
            height: 600px;
            width: 100%;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color:red;
        }
        h1 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            background:green;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color:green;
            color: white;
            border: 1px solid white;
            border-radius: 5px;
        }
        button:hover {
            background-color:red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Interactive Map of Lebanon</h1>
        <div id="map"></div>
        <div class="button-container">
            <button id="backHomeButton" >Back to Home</button>
            <button id="tour" >Tour Planner</button>
        </div>
    </div>
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        // Initialize the map
        var map = L.map('map').setView([33.8547, 35.8623], 8);

        // Base layers
        var osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var satellite = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.opentopomap.org/copyright">OpenTopoMap</a>'
        });

        // Add markers for specific landmarks
        var landmarks = [
            {name: "Beirut", coords: [33.8938, 35.5018], imageUrl: "images/beirut.jpg"},
            {name: "Tyre", coords: [33.2737, 35.2038], imageUrl: "images/tyree.jpg"},
            {name: "Harissa", coords: [33.9773, 35.6508], imageUrl: "images/haresa.jpg"},
            {name: "Sidon (Saida)", coords: [33.5561, 35.3769], imageUrl: "images/saidaa.jpg"},
            {name: "Cedars of God", coords: [34.2439, 36.0688], imageUrl: "images/cedars.jpg"},
            {name: "Jeita Grotto", coords: [33.9519, 35.6413], imageUrl: "images/JEITA.jpg"},
            {name: "Faraya Village", coords: [33.9833, 35.8333], imageUrl: "images/faraya.jpg"},
            {name: "Teleferique Lebanon", coords: [33.9802, 35.6157], imageUrl: "images/telefriq.jpg"},
            {name: "Beaufort Castle", coords: [33.325, 35.5325], imageUrl: "images/Beaufort.jpg"},
            {name: "Baatara Gorge Waterfall", coords: [34.1183, 35.9], imageUrl: "images/baatara.jpg"}
        ];

        landmarks.forEach(function(landmark) {
            L.marker(landmark.coords).addTo(map)
                .bindPopup(`<b>${landmark.name}</b><br><img src="${landmark.imageUrl}" alt="${landmark.name}" style="width:100%; height:auto;"><br>Coordinates: ${landmark.coords.join(', ')}`);
        });

        // Layer control
        var baseMaps = {
            "OpenStreetMap": osm,
            "Satellite": satellite
        };

        L.control.layers(baseMaps).addTo(map);

        // Add event listeners to the buttons
        document.getElementById('backHomeButton').addEventListener('click', function() {
            window.location.href = 'packages1.php'; 
        });    
        document.getElementById('tour').addEventListener('click', function() {
            window.location.href = 'tour.php'; 
        });
    </script>
</body>
</html>

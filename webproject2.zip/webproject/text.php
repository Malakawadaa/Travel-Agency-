<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>More Information About Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        h1 {
            background-color: red;
            color: black;
            padding: 20px 0;
            text-align: center;
            margin: 0;
        }
        .foo {
            background-color: red;
            color: black;
            font-size: 30px;
            text-align: center;
            padding: 20px 0;
            margin-top: 30px;
        }
        u {
            font-size: 30px;
        }
        p {
            font-size: 20px;
            padding: 0 20px;
            text-align: justify;
        }
        span {
            color: green;
            font-size: 20px;
        }
        .img {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }
        .img img {
            margin: 10px;
            max-width: 100%;
            height: auto;
        }
        @media (max-width: 768px) {
            h1, .foo {
                font-size: 24px;
            }
            p {
                font-size: 18px;
            }
        }
        @media (max-width: 480px) {
            u {
                font-size: 24px;
            }
            p {
                font-size: 16px;
            }
            h1, .foo {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <h1>Hello again</h1>
    <b><u>Discover the Wonders of Lebanon: Your Journey Begins Here!!!</u></b>
    <br><br>
    <p>Welcome to <span><a href="home.php" style="color: green;">LMD Traveling Agency</a></span>, where we turn your travel dreams into unforgettable experiences. From the ancient ruins of <span>Baalbek</span> to the vibrant streets of <span>Beirut</span>, we offer personalized itineraries that showcase the rich culture, stunning landscapes, and warm hospitality of <span>Lebanon</span>. Let us guide you through an adventure of a lifetime, tailored to your desires and filled with memories that will last forever.</p>
    <div class="img">
        <img src="images/kelna lbnen.jpg" alt="Kelna Lbnen">
        <img src="images/lbnena.jpg" alt="Lbnena">
    </div>
    <div class="foo">
        Enjoy Your Vacation With Us
    </div>
</body>
</html>
